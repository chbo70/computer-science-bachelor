#include "./libRA.c"
extern int scalar_product(int* A, int* B, int len);

void _start() {
    int size = 12, ref = 0;
    int A[size], B[size];

    // Initialisiere Zufallsgenerator
    srand(1234);

    // Initialisiere Vektoren und berechne Referenz
    println("Vektor A    Vektor B     Aᵢ * Bᵢ");
    println("--------    --------    --------");
    for (int i = 0; i < size; i++){
      int a = asr(rand(), 19);
      A[i] = a;
      hex(a);
      print("    ");
      int b = asr(rand(), 19);
      B[i] = b;
      hex(b);
      print("    ");
      int ab = a * b;
      ref += ab;
      hex(ab);
      newline();
    }
    println("                        --------");
    print("  Gewünschtes Ergebnis: ");
    hexln(ref);

    // Teste ARM-Implementierung
    int sp = scalar_product(A, B, size);
    print("  Ihre Implementierung: ");
    hexln(sp);

    if (sp != ref) {
      newline();
      println("Ihre Implementierung liefert ein falsches Ergebnis.");
      exit(1);
    }

    exit(0);
}
