// External interface
// ==================

extern void hex(int p);
extern void newline();
extern void put(char c);
extern void exit(int ret);
extern int asr(int x, int l);

// Booleans
// ========

#define true 1
#define false 0

// Helpers for printing
// ====================
// This function assumes that the argument is a null-terminated string.
// The strings we have seen in previous Assembly programs were not
// null-terminated. Do not use this implementation outside this project!

void print(char* chars){
  while(*chars)
    put(*chars++);
}

void println(char* chars){
  print(chars);
  newline();
}

void hexln(int p){
  hex(p);
  newline();
}

// Xorshift random number generator
// ================================
// This is a bad random number generator. Do not reuse it in other projects.
// Join our master lecture on Information Security for more details.
// https://en.wikipedia.org/wiki/Xorshift

static unsigned state;

void srand(unsigned seed){
  state = seed;
}

int rand(){
  state ^= state << 13;
  state ^= state >> 17;
  state ^= state << 5;
  return (int) state;
}
