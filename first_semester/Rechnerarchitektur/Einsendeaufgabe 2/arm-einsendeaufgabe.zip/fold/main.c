#include "./libRA.c"
extern int max(int* arr, unsigned int len);
extern int min(int* arr, unsigned int len);
extern int sum(int* arr, unsigned int len);
extern int fold(int init, int* arr, unsigned int len, void* agg);

int agg_max_c(int acc, int x) {
  if (acc < x) {
    return x;
  } else {
    return acc;
  }
}

int agg_min_c(int acc, int x) {
  if (x < acc) {
    return x;
  } else {
    return acc;
  }
}

int agg_sum_c(int acc, int x) {
  return (acc + x);
}

void _start() {
    int size = 20;
    int random_data[size];
    srand(123421);

    int first = (int) rand();
    random_data[0] = first;

    println("Initialisiere Array mit zufälligen Daten.");
    hex(first);
    for (int c = 1; c < size; c++){
      int num = (int) rand();
      random_data[c] = num;
      hex(num);
    }

    newline();
    println("Nutze ARM-Funktion fold mit C-Funktionen:");

    println("Das maximale Element ist:");
    hex(fold(first, random_data, size, &agg_max_c));

    println("Das minimale Element ist:");
    hex(fold(first, random_data, size, &agg_min_c));

    println("Die Summe aller Elemente ist:");
    hex(fold(0, random_data, size, &agg_sum_c));

    newline();
    println("Nutze ARM-Funktionen max, min und sum:");

    println("Das maximale Element ist:");
    hex(max(random_data, size));

    println("Das minimale Element ist:");
    hex(min(random_data, size));

    println("Die Summe aller Elemente ist:");
    hex(sum(random_data, size));

    exit(0);
}
