#!/usr/bin/env bash

# fail fast
set -o errexit
set -o nounset
set -o pipefail

if [ "$#" -ge 1 ] ; then
  id=$1
  ex=$(basename "$(pwd)")
  human=false
else
  human=true
fi

if $human ; then
  echo "Starte Tests..."
fi

date > test.log
sep="========================================================================"

if $human ; then
  check () {
    echo "$sep" >> test.log
    echo "Test: $3" >> test.log
    if eval "timeout -k 1s 1s $2" &>> test.log ; then
      printf "\e[0;32m✓\e[0m "
      echo "$3"
    else
      printf "\e[0;31m✗\e[0m "
      echo "$3"
    fi
  }
else
  check () {
    echo "$sep" >> test.log
    echo "Test: $3" >> test.log
    if eval "timeout -k 1s 1s $2" &>> test.log ; then
      echo "$id,$ex-$1"
    fi
  }
fi

if $human ; then
  check "toolchain" "make check-toolchain"     "Toolchain ist installiert"
  check "hashes"    "sha256sum -c .sha256sums" "Gebenene Dateien sind unverändert"
fi

check "compiles" "make clean main" "Projekt kompiliert mit \`make clean main\`"
check "runs"     "make run"        "Programm läuft fehlerfrei mit \`make run\`"

mkdir -p tests
declare -i i=-1
incr () {
  i=$((i+1))
}

c_check () {
  label=$1
  msg=$2
  agg=$3
  fn=$4
  size=${5:-20}
  seed=${6:-123233}
  incr
  cat << EOF > tests/main.$i.c
#include "../libRA.c"
extern int max(int* arr, int len);
extern int min(int* arr, int len);
extern int sum(int* arr, int len);

void _start() {
    int size = $size;
    unsigned random_data[size];
    srand($seed);
    int first = (int) rand();
    random_data[0] = first;
    int acc = first;
    for (int c = 1; c < size; c++){
      int num = (int) rand();
      random_data[c] = num;
      $agg;
    }

    if (size <= 0) {
      println("Die Funktion liefert das gewünschte Ergebnis.");
      exit(0);
    }

    int check = $fn(random_data, size);

    if (check != acc) {
      println("Die Funktion ($fn) liefert nicht das gewünschte Ergebnis.");
      println("Array:");
      for (int c = 0; c < size; c++) hex(random_data[c]);
      println("Erwartet:");
      hex(acc);
      println("Erhalten:");
      hex(check);
      exit(1);
    }

    println("Die Funktion liefert das gewünschte Ergebnis.");
    exit(0);
}
EOF
  check "$label" "make run.test.$i" "$msg"
}

test_fn () {
  agg=$2
  fn=$1
  c_check "$fn-ok"    "$fn funktioniert" "$agg" "$fn"
  c_check "$fn-other" "$fn funktioniert mit anderen Zahlen" "$agg" "$fn" 20 2167132
  c_check "$fn-big"   "$fn funktioniert mit großem Array" "$agg" "$fn" 20000 387324
  c_check "$fn-small" "$fn funktioniert mit kleinem Array" "$agg" "$fn" 1 2147
  c_check "$fn-zero"  "$fn toleriert size = 0" "$agg" "$fn" 0
}
test_fn max "if (num > acc) acc = num"
test_fn min "if (num < acc) acc = num"
test_fn sum "acc += num"

c_check_restore () {
  label=$1
  msg=$2
  seed=${3:-12309233}
  incr
  cat << EOF > tests/main.$i.c
#include "../libRA.c"

extern int max(int* arr, int len);
extern int min(int* arr, int len);
extern int sum(int* arr, int len);

void _start() {
  int size = 100;
  unsigned random_data[size];
  srand($seed);
  int first = (int) rand();
  random_data[0] = first;
  int acc = first;
  for (int c = 1; c < size; c++){
    int num = (int) rand();
    random_data[c] = num;
  }

  DUMP_REGISTERS(before);
  sum(random_data, size);
  DUMP_REGISTERS(after);
  int reg_stat = arm_eval_restored_registers(before, after);
  if(reg_stat != 0) {
    println("Register nicht wiederhergestellt!");
    hex(reg_stat);
    exit(1);
  }

  exit(0);
}
EOF
  check "$label" "make run.test.$i" "$msg"
}

if ! $human ; then
  c_check_restore "restore" "Aufrufkonvention: Register wurden wiederhergestellt"
fi

if $human ; then
  echo "Tests abgeschlossen."
  echo
  echo "Sie finden eine detaillierte Ausgabe in \`test.log\`."
fi
