#include "./libRA.c"
extern int max(int* arr, unsigned int len);
extern int min(int* arr, unsigned int len);
extern int sum(int* arr, unsigned int len);

void _start() {
    int size = 20;
    int random_data[size];
    srand(12309233);

    println("Initialisiere Array mit zufälligen Daten.");
    for (int c = 0; c < size; c++){
      int num = (int) rand();
      random_data[c] = num;
      hex(num);
    }

    int max_element = max(random_data, size);
    int min_element = min(random_data, size);
    int sum_array   = sum(random_data, size);

    println("Das maximale Element ist:");
    hex(max_element);

    println("Das minimale Element ist:");
    hex(min_element);

    println("Die Summe aller Elemente ist:");
    hex(sum_array);

    exit(0);
}
