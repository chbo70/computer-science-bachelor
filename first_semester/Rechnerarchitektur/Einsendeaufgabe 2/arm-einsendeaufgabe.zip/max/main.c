#include "./libRA.c"
extern int max(int* arr, unsigned int len);

/*
Erklärung:
  Da wir ohne C-Standard-Bibliothek kompilieren verwenden wir _start statt main
  als Einsprungspunkt.
  Die Bibliotheksfunktionen exit, hex, rand, srand, println werden in libRA.c
  definiert und zum Teil in libRA.S implementiert. Die einzelnen Dateien werden
  beim Linken zusammengefügt (siehe Makefile).
*/
void _start() {
    int size = 20;
    int random_data[size];
    srand(12309183);

    println("Initialisiere Array mit zufälligen Daten.");
    for (int c = 0; c < size; c++){
      int num = (int) rand();
      random_data[c] = num;
      hex(num);
    }

    int max_element = max(random_data, size);

    println("Das maximale Element ist:");
    hex(max_element);

    exit(0);
}
