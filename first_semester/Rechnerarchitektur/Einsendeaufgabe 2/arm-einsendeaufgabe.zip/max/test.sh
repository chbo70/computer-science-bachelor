#!/usr/bin/env bash

# fail fast
set -o errexit
set -o nounset
set -o pipefail

if [ "$#" -ge 1 ] ; then
  id=$1
  ex=$(basename "$(pwd)")
  human=false
else
  human=true
fi

if $human ; then
  echo "Starte Tests..."
fi

date > test.log
sep="========================================================================"

if $human ; then
  check () {
    echo "$sep" >> test.log
    echo "Test: $3" >> test.log
    if eval "timeout -k 1s 1s $2" &>> test.log ; then
      printf "\e[0;32m✓\e[0m "
      echo "$3"
    else
      printf "\e[0;31m✗\e[0m "
      echo "$3"
    fi
  }
else
  check () {
    echo "$sep" >> test.log
    echo "Test: $3" >> test.log
    if eval "timeout -k 1s 1s $2" &>> test.log ; then
      echo "$id,$ex-$1"
    fi
  }
fi

if $human ; then
  check "toolchain" "make check-toolchain"     "Toolchain ist installiert"
  check "hashes"    "sha256sum -c .sha256sums" "Gebenene Dateien sind unverändert"
fi

check "compiles" "make clean main" "Projekt kompiliert mit \`make clean main\`"
check "runs"     "make run"        "Programm läuft fehlerfrei mit \`make run\`"

mkdir -p tests
declare -i i=-1
incr () {
  i=$((i+1))
}

c_check () {
  label=$1
  msg=$2
  size=${3:-20}
  seed=${4:-12303}
  incr
  cat << EOF > tests/main.$i.c
#include "../libRA.c"
extern int max(int* arr, int len);

void _start() {
    int size = $size;
    int random_data[size];
    srand($seed);
    int first = (int) rand();
    random_data[0] = first;
    int acc = first;
    for (int c = 1; c < size; c++){
      int num = (int) rand();
      random_data[c] = num;
      if (num > acc) acc = num;
    }
    int max_element = max(random_data, size);

    if (size <= 0 || max_element == acc) {
      println("Die Funktion liefert das gewünschte Ergebnis.");
      exit(0);
    } else {
      println("Die Funktion liefert nicht das gewünschte Ergebnis.");
      exit(1);
    }
}
EOF
  check "$label" "make run.test.$i" "$msg"
}
c_check "ok"    "max funktioniert"
c_check "other" "max funktioniert mit anderen Zahlen" 20 213013
c_check "big"   "max funktioniert mit großem Array" 20000 32432
c_check "small" "max funktioniert mit kleinem Array" 1 21313
c_check "zero"  "max toleriert size = 0" 0

c_check_restore () {
  label=$1
  msg=$2
  seed=${3:-12309233}
  incr
  cat << EOF > tests/main.$i.c
#include "../libRA.c"
extern int max(int* arr, int len);

void _start() {
  int size = 100;
  unsigned random_data[size];
  srand($seed);
  int first = (int) rand();
  random_data[0] = first;
  int acc = first;
  for (int c = 1; c < size; c++){
    int num = (int) rand();
    random_data[c] = num;
  }

  DUMP_REGISTERS(before);
  max(random_data, size);
  DUMP_REGISTERS(after);
  int reg_stat = arm_eval_restored_registers(before, after);
  if(reg_stat != 0) {
    println("Register nicht wiederhergestellt!");
    hex(reg_stat);
    exit(1);
  }

  exit(0);
}
EOF
  check "$label" "make run.test.$i" "$msg"
}

if ! $human ; then
  c_check_restore "restore" "Aufrufkonvention: Register wurden wiederhergestellt"
fi

if $human ; then
  echo "Tests abgeschlossen."
  echo
  echo "Sie finden eine detaillierte Ausgabe in \`test.log\`."
fi
