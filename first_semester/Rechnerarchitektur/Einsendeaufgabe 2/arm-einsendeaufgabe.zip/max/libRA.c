// External interface
// ==================

extern void hex(int p);
extern void newline();
extern void put(char c);
extern void exit(int ret);

// Booleans
// ========

#define true 1
#define false 0

// Helper for printing
// ===================
// This function assumes that the argument is a null-terminated string.
// The strings we have seen in previous Assembly programs were not
// null-terminated. Do not use this implementation outside this project!

void println(char* chars){
  while(*chars)
    put(*chars++);
  newline();
}

// Linear congruential random number generator
// ===========================================
// This is a bad random number generator. Do not reuse it in other projects.
// Join our master lecture on Information Security for more details.
// https://stackoverflow.com/questions/47191747/generating-random-numbers-without-using-cstdlib

#define MY_RAND_MAX = 2147483647
static unsigned long my_rand_state = 1;

void srand(unsigned long seed){
  my_rand_state = seed;
}

long rand(){
  my_rand_state = (my_rand_state * 1103515245 + 12345) % 2147483648;
  return my_rand_state;
}

// Register Sorcery
// ================
// It's none of your business!

struct ArmRegisters {
  int sr[13];
};

#define DUMP_REGISTERS(TARGET_NAME) \
  struct ArmRegisters TARGET_NAME; \
  asm volatile("STR r0 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[0])); \
  asm volatile("STR r1 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[1])); \
  asm volatile("STR r2 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[2])); \
  asm volatile("STR r3 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[3])); \
  asm volatile("STR r4 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[4])); \
  asm volatile("STR r5 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[5])); \
  asm volatile("STR r6 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[6])); \
  asm volatile("STR r7 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[7])); \
  asm volatile("STR r8 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[8])); \
  asm volatile("STR r9 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[9])); \
  asm volatile("STR r10 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[10])); \
  asm volatile("STR r11 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[11])); \
  asm volatile("STR r12 , [%[addr]]" : : [addr] "r" (&TARGET_NAME.sr[12]));

int arm_eval_restored_register(struct ArmRegisters a, struct ArmRegisters b, int n) {
  if (a.sr[n] != b.sr[n]){
    println("Start: Register wurde nicht wiederhergestellt.");
    println("Register:");
    hex(n);
    println("Wert vor dem Aufruf:");
    hex(a.sr[n]);
    println("Wert nach dem Aufruf:");
    hex(b.sr[n]);
    println("Ende: Register wurde nicht wiederhergestellt.");
    return 1 << (n+1);
  }
  return 0;
}

int arm_eval_restored_registers(struct ArmRegisters a, struct ArmRegisters b){
  return
    arm_eval_restored_register(a,b,4) |
    arm_eval_restored_register(a,b,5) |
    arm_eval_restored_register(a,b,6) |
    arm_eval_restored_register(a,b,7) |
    arm_eval_restored_register(a,b,8) |
    arm_eval_restored_register(a,b,9) |
    arm_eval_restored_register(a,b,10);
    // arm_eval_restored_register(a,b,11) |
    // arm_eval_restored_register(a,b,12) ;
    // https://community.arm.com/developer/tools-software/oss-platforms/f/dev-platforms-forum/5436/i-want-to-know-meaning-of-r12-register
}
