#!/usr/bin/env bash

# fail fast
set -o errexit
set -o nounset
set -o pipefail

if [ "$#" -ge 1 ] ; then
  id=$1
  ex=$(basename "$(pwd)")
  human=false
else
  human=true
fi

if $human ; then
  echo "Starte Tests..."
fi

date > test.log
sep="========================================================================"

if $human ; then
  check () {
    echo "$sep" >> test.log
    echo "Test: $3" >> test.log
    if eval "timeout -k 1s 1s $2" &>> test.log ; then
      printf "\e[0;32m✓\e[0m "
      echo "$3"
    else
      printf "\e[0;31m✗\e[0m "
      echo "$3"
    fi
  }
else
  check () {
    echo "$sep" >> test.log
    echo "Test: $3" >> test.log
    if eval "timeout -k 1s 1s $2" &>> test.log ; then
      echo "$id,$ex-$1"
    fi
  }
fi

if $human ; then
  check "toolchain" "make check-toolchain"     "Toolchain ist installiert"
  check "hashes"    "sha256sum -c .sha256sums" "Gebenene Dateien sind unverändert"
fi

check "compiles" "make clean main" "Projekt kompiliert mit \`make clean main\`"
check "runs"     "make run"        "Programm läuft fehlerfrei mit \`make run\`"

mkdir -p tests
declare -i i=-1
incr () {
  i=$((i+1))
}

c_check () {
  label=$1
  msg=$2
  s=${3:-1}
  n=${4:-30}
  incr
  cat << EOF > tests/main.$i.c
#include "../libRA.c"
extern int fib(int n);

int fib_intern(int n) {
  if (n < 2) { return n; }
  return fib_intern(n-1) + fib_intern(n-2);
}

void _start() {
  int n = $n;
  int right = 0;
  for (int c = $s; c <= n; c++){
    int expect = fib_intern(c);
    int is = fib(c);
    println("Expected:");
    hex(expect);
    println("Got:");
    hex(is);
    if(expect == is) { right++; }
  }
  int failed = ((n) - ($s -1) - right);
  if ( failed == 0 ){
    println("Die Funktion liefert das gewünschte Ergebnis.");
  } else {
    println("Die Funktion liefert nicht das gewünschte Ergebnis.");
  }
  exit(failed);
}
EOF
  check "$label" "make run.test.$i" "$msg"
}

c_check "low"  "fib funktioniert für n=0 bis n=2" 0 2
c_check "high" "fib funktioniert für n=3 bis n=30" 3 30

c_check_restore () {
  label=$1
  msg=$2
  incr
  cat << EOF > tests/main.$i.c
#include "../libRA.c"
extern int fib(int n);

void _start() {
  for (int c = c; c <= 15; c++){
    DUMP_REGISTERS(before);
    int is = fib(c);
    DUMP_REGISTERS(after);
    int reg_stat = arm_eval_restored_registers(before, after);
    if(reg_stat != 0) {
      println("Register nicht wiederhergestellt!");
      hex(reg_stat);
      exit(1);
    }
  }
  exit(0);
}
EOF
  check "$label" "make run.test.$i" "$msg"
}

c_check_recurse () {
  label=$1
  msg=$2
  incr
  cat << EOF > tests/main.$i.c
#include "../libRA.c"
extern int fib(int n);

void _start() {
  int canary;
  int canary_after;

  // -128 is hardcoded and only triggered/overwritten with fib(n) where n > 7
  // This is not a general test, but suffices for this exercise.
  canary = rand();
  asm volatile("STR %[src], [sp, #-128]" : : [src] "r" (canary));

  fib(15);

  asm volatile("LDR %[dst], [sp, #-128]" : [dst] "=r" (canary_after) :);
  if (canary == canary_after){
    println("Die Funktion nutzt keine Rekursion!");
    exit(2);
  }

  exit(0);
}
EOF
  check "$label" "make run.test.$i" "$msg"
}

if ! $human ; then
  c_check_restore "restore" "Aufrufkonvention: Register wurden wiederhergestellt"
  c_check_recurse "recurse" "fib ist rekursiv implementiert (getestet an n=15)"
fi

if $human ; then
  echo "Tests abgeschlossen."
  echo
  echo "Sie finden eine detaillierte Ausgabe in \`test.log\`."
fi
