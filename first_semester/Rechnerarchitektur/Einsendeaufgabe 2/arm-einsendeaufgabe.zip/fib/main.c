#include "./libRA.c"
extern int fib(unsigned int n);

void _start() {
  println("Berechne fib(n) mit n: 1-10:");
  for (int i = 1; i < 10; i ++) {
    hex(fib(i));
  }
  exit(0);
}
