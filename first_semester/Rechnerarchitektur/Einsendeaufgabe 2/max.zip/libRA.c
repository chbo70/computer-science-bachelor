extern void hex(int p);
extern void newline();
extern void put(char c);
extern void exit(int ret);

//int my_main();

// Assuming all strings are null terminated. Very bad code, don't do this at home!
void println(char* chars){
    while(*chars)
        put(*chars++);
    newline();
}

// https://stackoverflow.com/questions/47191747/generating-random-numbers-without-using-cstdlib
// linear congruential generator
#define MY_RAND_MAX = 2147483647
static unsigned long my_rand_state = 1;

void srand(unsigned long seed){
    my_rand_state = seed;
}

long rand(){
    my_rand_state = (my_rand_state * 1103515245 + 12345) % 2147483648;
    return my_rand_state;
}
/*
void _start() {
  int ret = my_main();
  exit(ret); 
}
*/