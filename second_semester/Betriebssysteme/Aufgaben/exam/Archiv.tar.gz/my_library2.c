int function1(int x){
    return x*x*x;
}
int function2(int x){
    return x * 3;
}