int reset(int x) {
    x = 0;
    return x;
}