int doubling(int x) {
    return (x * 2);
}