int rightshift(int x) {
    return x >> 1;
}