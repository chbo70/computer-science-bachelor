int leftshift(int x) {
    return x << 1;
}