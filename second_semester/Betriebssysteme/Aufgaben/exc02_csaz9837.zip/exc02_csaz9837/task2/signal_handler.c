#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void termination_handler(int signum) {
	switch (signum)
    {
    case (SIGINT):
        printf("received: SIGINT\n");
        break;
    case (SIGUSR1):
        printf("received: SIGUSR1\n");
        break;
    case (SIGTERM):
        printf("received: SIGTERM\n");
        break;
    case (SIGKILL):
        printf("received: SIGKILL\n");
    default:
        break;
    }
}

int main(void) {
    //signals are listed in man 7 signal
    //pid can be determined with ps ax | grep processname
	struct sigaction new_action;
	new_action.sa_handler = termination_handler;
	//kill -2 <pid>
	sigaction(SIGINT, &new_action, NULL);
    //kill -10 <pid>
	sigaction(SIGUSR1, &new_action, NULL);
    //kill -9 <pid>, note that SIGKILL cannot be caught or ignored
	sigaction(SIGKILL, &new_action, NULL);
    //kill -15 <pid>
    sigaction(SIGTERM, &new_action, NULL);

	while(1) {
		usleep(10);
	}

	return EXIT_SUCCESS;
}