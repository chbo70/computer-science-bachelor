int plugin(int num) {
    return num + 1;
}
