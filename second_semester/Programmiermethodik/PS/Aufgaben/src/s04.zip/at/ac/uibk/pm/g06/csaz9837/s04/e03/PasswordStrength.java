package at.ac.uibk.pm.g06.csaz9837.s04.e03;

public enum PasswordStrength {
    TOO_WEAK,
    WEAK,
    MEDIUM,
    STRONG
}
