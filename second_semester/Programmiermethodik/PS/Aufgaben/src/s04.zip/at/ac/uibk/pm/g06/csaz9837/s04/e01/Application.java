package at.ac.uibk.pm.g06.csaz9837.s04.e01;

public class Application {
    public static void main(String[] args) {
        MyLinkedList link = new MyLinkedList();
        link.get(1);
    }
}
