package at.ac.uibk.pm.g06.csaz9837.s05.e02;

public class MyCustomClass1 extends Object {

    private Integer attribute1;
    private String attribute2;
    private Double attribute3;
    private int attribute4;

    public MyCustomClass1(Integer attribute1, String attrubute2, Double attrubute3, int attribute4) {
        this.attribute1 = attribute1;
        this.attribute2 = attrubute2;
        this.attribute3 = attrubute3;
        this.attribute4 = attribute4;
    }

}
