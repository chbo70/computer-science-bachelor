package at.ac.uibk.pm.g06.csaz9837.s05.e04;

public class Person {
    private String name;

    public Person(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
