package at.ac.uibk.pm.csaz9837.exam1.e02;

public class InvalidDateRange extends Exception{

    public void printException(){
        System.err.println("InvalidDateRange");
    }
}
