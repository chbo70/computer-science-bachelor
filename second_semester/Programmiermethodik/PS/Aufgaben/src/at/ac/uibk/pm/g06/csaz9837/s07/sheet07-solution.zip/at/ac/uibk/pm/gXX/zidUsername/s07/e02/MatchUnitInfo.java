package at.ac.uibk.pm.gXX.zidUsername.s07.e02;

public class MatchUnitInfo<T extends Comparable<T>> {

	private Player player;
	private T score;
	private Result result;

	public MatchUnitInfo(Player player) {
		this.player = player;
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public T getScore() {
		return score;
	}

	public void setScore(T result) {
		this.score = result;
	}

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

}
