package at.ac.uibk.pm.gXX.zidUsername.s07.e02;

public class Encounter<T extends Comparable<T>> {

	private MatchUnitInfo<T> player1;
	private MatchUnitInfo<T> player2;

	public Encounter(Player player1, Player player2) {
		this.player1 = new MatchUnitInfo<>(player1);
		this.player2 = new MatchUnitInfo<>(player2);
	}

	public MatchUnitInfo<T> getPlayer1() {
		return player1;
	}

	public MatchUnitInfo<T> getPlayer2() {
		return player2;
	}

}
