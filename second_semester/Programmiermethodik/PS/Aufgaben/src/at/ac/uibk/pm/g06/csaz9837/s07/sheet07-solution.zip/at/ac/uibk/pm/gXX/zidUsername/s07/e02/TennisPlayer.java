package at.ac.uibk.pm.gXX.zidUsername.s07.e02;

/**
 * Seems pretty useless this class. It's just a concrete implementation of
 * Player.
 * 
 * @author Alexander Blaas
 *
 */
public class TennisPlayer extends Player {

	public TennisPlayer(String name) {
		super(name);
	}

}
