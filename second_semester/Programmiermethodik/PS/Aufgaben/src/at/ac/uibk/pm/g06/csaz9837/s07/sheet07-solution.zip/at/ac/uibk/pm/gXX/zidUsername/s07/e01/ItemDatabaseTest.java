package at.ac.uibk.pm.gXX.zidUsername.s07.e01;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ItemDatabaseTest {

	private InMemoryDatabase<Long, Item> database;

	@BeforeEach
	public void fillDatabase() throws AlreadyInCollectionException {
		database = new InMemoryDatabase<>();
		database.save(new Item(1L, "Item", 12.99));
		database.save(new Item(2L, "Item2", 5.99));
		database.save(new Item(3L, "Item3", 16.99));
	}

	@Test
	public void testFindItem() {
		Item item = database.find(1L).orElseThrow();
		assertEquals(1L, item.getId(), 0);
		assertEquals("Item", item.getName());
		assertEquals(12.99, item.getPrice(), 0.1);
	}

	@Test
	public void testFindInvalidItem() {
		assertTrue(database.find(100L).isEmpty());
	}

	@Test
	public void testSaveValidItem() throws AlreadyInCollectionException {
		Item newItem = new Item(10L, "New", 1.99);
		Item savedItem = database.save(newItem);

		assertEquals(newItem.getId(), savedItem.getId());
		assertEquals(newItem.getName(), savedItem.getName());
		assertEquals(newItem.getPrice(), savedItem.getPrice(), 0.1);
	}

	@Test
	public void testSaveInvalidItem() {
		Item newItem = new Item(1L, "Item", 12.99);
		assertThrows(AlreadyInCollectionException.class, () -> database.save(newItem));
	}

	@Test
	public void testDeleteValidItem() throws NoSuchElementException {
		Item itemToDelete = database.find(3L).orElseThrow();
		database.delete(itemToDelete);
		assertTrue(database.find(3L).isEmpty());
	}

	@Test
	public void testDeleteInvalidItem() {
		assertThrows(NoSuchElementException.class, () -> database.delete(new Item(1111L, "Item", Double.MAX_VALUE)));
	}

	@Test
	public void test() {
		List<Item> sorted = database.sort(Comparator.comparing(Item::getName));
		assertTrue(isSorted(sorted.stream().map(Item::getName).toList()));
	}

	private boolean isSorted(List<String> list) {
		boolean sorted = true;
		for (int i = 1; i < list.size(); i++) {
			if (list.get(i - 1).compareTo(list.get(i)) > 0) {
				sorted = false;
				break;
			}
		}

		return sorted;
	}
}
