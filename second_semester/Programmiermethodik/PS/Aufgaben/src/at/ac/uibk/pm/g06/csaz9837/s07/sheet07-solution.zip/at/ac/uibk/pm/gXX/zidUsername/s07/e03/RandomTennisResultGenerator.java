package at.ac.uibk.pm.gXX.zidUsername.s07.e03;

public class RandomTennisResultGenerator extends RandomResultGenerator<Integer> {

	@Override
	protected Integer generateRandomElement() {
		return this.getRandom().nextInt(7);
	}

}
