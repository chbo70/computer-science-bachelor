package at.ac.uibk.pm.gXX.zidUsername.s07.e03;

import java.util.Comparator;
import java.util.Random;

import at.ac.uibk.pm.gXX.zidUsername.s07.e02.MatchUnitInfo;
import at.ac.uibk.pm.gXX.zidUsername.s07.e02.Result;
import at.ac.uibk.pm.gXX.zidUsername.s07.e02.ResultGenerator;

public abstract class RandomResultGenerator<T extends Comparable<T>> implements ResultGenerator<T> {

	private Random random = new Random();

	@Override
	public void generateAndAssignResults(MatchUnitInfo<T> player1, MatchUnitInfo<T> player2, Comparator<T> comparator) {
		T resultPlayer1 = this.generateRandomElement();
		T resultPlayer2 = this.generateRandomElement();

		player1.setScore(resultPlayer1);
		player2.setScore(resultPlayer2);

		Result gameResultPlayer1 = null;
		Result gameResultPlayer2 = null;

		int scoreComparison = resultPlayer1.compareTo(resultPlayer2);

		switch (scoreComparison) {
		case -1:
			gameResultPlayer1 = Result.VICTORY;
			gameResultPlayer2 = Result.LOSS;
			break;
		case 1:
			gameResultPlayer1 = Result.LOSS;
			gameResultPlayer2 = Result.VICTORY;
			break;
		default:
			gameResultPlayer1 = Result.DRAW;
			gameResultPlayer2 = Result.DRAW;
		}

		player1.setResult(gameResultPlayer1);
		player2.setResult(gameResultPlayer2);
	}

	protected abstract T generateRandomElement();

	protected Random getRandom() {
		return random;
	}

}
