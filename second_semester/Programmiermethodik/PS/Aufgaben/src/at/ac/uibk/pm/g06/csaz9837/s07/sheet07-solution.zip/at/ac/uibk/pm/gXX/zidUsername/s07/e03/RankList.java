package at.ac.uibk.pm.gXX.zidUsername.s07.e03;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import at.ac.uibk.pm.gXX.zidUsername.s07.e02.Group;
import at.ac.uibk.pm.gXX.zidUsername.s07.e02.Player;
import at.ac.uibk.pm.gXX.zidUsername.s07.e02.RankListEntry;

public class RankList<T extends Comparable<T>> {

	private static final int LEADING_PLAYERS = 2;
	private List<RankListEntry> rankListEntries;
	private Comparator<RankListEntry> comparator;

	public RankList(Collection<RankListEntry> rankListEntries, Comparator<RankListEntry> comparator) {
		// needs to be a fresh array instance
		this.rankListEntries = new ArrayList<>(rankListEntries);
		this.comparator = comparator;
	}

	private void sort() {
		Collections.sort(this.rankListEntries, this.comparator);
	}

	public List<Player> findLeadingPlayers() {
		// first sort
		this.sort();
		// then get the leading x players
		if (this.rankListEntries.size() < LEADING_PLAYERS) {
			throw new IllegalArgumentException("Number of leading player is higher than given rank list");
		}
		return this.rankListEntries.subList(0, LEADING_PLAYERS).stream().map(RankListEntry::getPlayer).toList();
	}

	public void print(Group<T> group) {
		// sort first
		this.sort();
		// then print
		int i = 1;
		System.out.println(group.getName() + ": ");
		System.out.println("============================================================");
		for (RankListEntry entry : this.rankListEntries) {
			System.out.println(i + "\t" + entry.toString());
			i++;
		}
		System.out.println();
	}

}
