package at.ac.uibk.pm.gXX.zidUsername.s07.e01;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;

public class InMemoryDatabase<U, T extends Identifiable<U>> {

	private Map<U, T> storage = new HashMap<>();

	public T save(T entry) throws AlreadyInCollectionException {
		U entityId = entry.getId();
		if (storage.containsKey(entityId)) {
			throw new AlreadyInCollectionException("The Element is already in the database!");
		}
		storage.put(entityId, entry);

		return entry;
	}

	public void delete(T entry) throws NoSuchElementException {
		if (!storage.containsKey(entry.getId())) {
			throw new NoSuchElementException("The Element is not in the database!");
		}
		storage.remove(entry.getId());
	}

	public Optional<T> find(U id) {
		return Optional.ofNullable(storage.get(id));
	}

	public List<T> sort(Comparator<T> comparator) {
		return storage.values().stream().sorted(comparator).toList();
	}
}
