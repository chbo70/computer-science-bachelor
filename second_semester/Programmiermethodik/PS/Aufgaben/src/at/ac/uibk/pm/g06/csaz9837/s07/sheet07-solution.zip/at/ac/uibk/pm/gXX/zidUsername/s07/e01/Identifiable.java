package at.ac.uibk.pm.gXX.zidUsername.s07.e01;

public interface Identifiable<T> {
    T getId();
}
