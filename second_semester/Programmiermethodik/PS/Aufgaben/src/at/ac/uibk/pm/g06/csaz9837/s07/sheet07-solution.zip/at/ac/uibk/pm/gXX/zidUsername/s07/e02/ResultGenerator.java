package at.ac.uibk.pm.gXX.zidUsername.s07.e02;

import java.util.Comparator;

public interface ResultGenerator<T extends Comparable<T>> {

	void generateAndAssignResults(MatchUnitInfo<T> player1, MatchUnitInfo<T> player2, Comparator<T> comparator);

}
