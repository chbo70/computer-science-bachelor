package at.ac.uibk.pm.gXX.zidUsername.s07.e01;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class UserDatabaseTest {

	private InMemoryDatabase<String, User> database;

	@BeforeEach
	public void fillDatabase() throws AlreadyInCollectionException {
		database = new InMemoryDatabase<>();
		database.save(new User("admin", "Admin", "Istrator"));
		database.save(new User("user1", "Werner", "Kogler"));
		database.save(new User("user2", "Sebastian", "Kurz"));
		database.save(new User("user3", "Martin", "Kocher"));
	}

	@Test
	public void testFindUser() {
		User user = database.find("admin").orElseThrow();
		assertEquals("admin", user.getId());
		assertEquals("Admin", user.getName());
		assertEquals("Istrator", user.getSurname());
	}

	@Test
	public void testFindInvalidUser() {
		assertTrue(database.find("invalid user").isEmpty());
	}

	@Test
	public void testSaveValidUser() throws AlreadyInCollectionException {
		User newUser = new User("user9", "New", "User");
		User savedUser = database.save(newUser);

		assertEquals(newUser.getId(), savedUser.getId());
		assertEquals(newUser.getName(), savedUser.getName());
		assertEquals(newUser.getSurname(), savedUser.getSurname());
	}

	@Test
	public void testSaveInvalidUser() {
		User newUser = new User("admin", "Admin", "Istrator");
		assertThrows(AlreadyInCollectionException.class, () -> database.save(newUser));
	}

	@Test
	public void testDeleteValidUser() throws NoSuchElementException {
		User userToDelete = database.find("user2").orElseThrow();
		database.delete(userToDelete);
		assertTrue(database.find("user2").isEmpty());
	}

	@Test
	public void testDeleteInvalidUser() {
		assertThrows(NoSuchElementException.class,
				() -> database.delete(new User("Does not exist", "Admin", "Istrator")));
	}

	@Test
	public void testSort() {
		List<User> sorted = database.sort(Comparator.comparing(User::getName));
		assertTrue(isSorted(sorted.stream().map(User::getName).toList()));
	}

	private boolean isSorted(List<String> list) {
		boolean sorted = true;
		for (int i = 1; i < list.size(); i++) {
			if (list.get(i - 1).compareTo(list.get(i)) > 0) {
				sorted = false;
				break;
			}
		}

		return sorted;
	}
}
