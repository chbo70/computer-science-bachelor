package at.ac.uibk.pm.gXX.zidUsername.s07.e02;

import java.util.EnumMap;
import java.util.Map;

public class RankListEntry {

	private final Player player;
	private Long totalAmountOfPoints = 0L;
	private Map<Result, Long> resultStatistics = new EnumMap<>(Result.class);

	public RankListEntry(Player player) {
		this.player = player;
		// init result-statistics
		this.resultStatistics.put(Result.VICTORY, 0L);
		this.resultStatistics.put(Result.DRAW, 0L);
		this.resultStatistics.put(Result.LOSS, 0L);
	}

	public void processResult(Result result) {
		// statistcs
		Long oldResult = this.resultStatistics.get(result);
		this.resultStatistics.replace(result, oldResult + 1);
		// increase points
		this.totalAmountOfPoints += result.getPoints();
	}

	public Player getPlayer() {
		return player;
	}

	public Long getTotalAmountOfPoints() {
		return totalAmountOfPoints;
	}

	private long calcTotalNumberOfGames() {
		return this.resultStatistics.get(Result.VICTORY) + this.resultStatistics.get(Result.DRAW)
				+ this.resultStatistics.get(Result.LOSS);
	}

	@Override
	public String toString() {
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append(this.player.getName());
		strBuilder.append("\t");
		strBuilder.append(this.calcTotalNumberOfGames());
		strBuilder.append("\t");
		strBuilder.append(this.resultStatistics.get(Result.VICTORY));
		strBuilder.append("\t");
		strBuilder.append(this.resultStatistics.get(Result.DRAW));
		strBuilder.append("\t");
		strBuilder.append(this.resultStatistics.get(Result.LOSS));
		strBuilder.append("\t");
		strBuilder.append(this.totalAmountOfPoints);

		return strBuilder.toString();
	}


}
