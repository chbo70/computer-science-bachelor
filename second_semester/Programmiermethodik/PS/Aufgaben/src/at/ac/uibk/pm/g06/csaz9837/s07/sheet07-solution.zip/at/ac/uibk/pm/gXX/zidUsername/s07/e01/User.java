package at.ac.uibk.pm.gXX.zidUsername.s07.e01;

import java.util.Objects;

public class User implements Identifiable<String> {
	private String name;
	private String surname;
	private final String username;

	public User(String username, String name, String surname) {
		this.name = name;
		this.surname = surname;
		this.username = username;
	}

	@Override
	public String getId() {
		return this.username;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	@Override
	public int hashCode() {
		return Objects.hash(username);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		return Objects.equals(username, other.username);
	}
}
