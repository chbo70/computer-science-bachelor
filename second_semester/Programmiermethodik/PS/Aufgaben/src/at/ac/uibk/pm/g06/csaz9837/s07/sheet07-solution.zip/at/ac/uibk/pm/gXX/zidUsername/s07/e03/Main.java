package at.ac.uibk.pm.gXX.zidUsername.s07.e03;

public class Main {

	public static void main(String[] args) {
		int numberOfPlayers = 20;
		int numberOfGroups = 4;
		new TournamentSimulator().simulateTournament(numberOfPlayers, numberOfGroups);
	}

}
