package at.ac.uibk.pm.gXX.zidUsername.s07.e02;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.IntStream;

public class RandomGroupGenerator<T extends Comparable<T>> implements GroupGenerator<T> {

	@Override
	public List<Group<T>> createGroups(List<Player> competingEntities, int numberOfGroups) {
		List<Player> shuffeledEntities = new ArrayList<>(competingEntities);
		Collections.shuffle(shuffeledEntities);

		List<Group<T>> groups = IntStream.range(0, numberOfGroups).mapToObj(i -> new Group<T>("Group" + i)).toList();
		int nrPlayers = competingEntities.size();
		int assignedPlayer = 0;

		while (assignedPlayer < nrPlayers) {
			for (int i = 0; i < numberOfGroups && assignedPlayer < nrPlayers; i++, assignedPlayer++) {
				groups.get(i).addPlayer(competingEntities.get(assignedPlayer));
			}
		}
		return groups;
	}

}
