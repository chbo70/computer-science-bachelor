package at.ac.uibk.pm.gXX.zidUsername.s07.e02;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import at.ac.uibk.pm.gXX.zidUsername.s07.e03.RankList;

public class TournamentManager<T extends Comparable<T>> {

	private List<Player> players = new ArrayList<>();
	private Comparator<T> resultComparator;
	private Comparator<RankListEntry> rankListComparator;

	public TournamentManager(Comparator<T> resultComparator, Comparator<RankListEntry> rankListComparator) {
		this.resultComparator = resultComparator;
		this.rankListComparator = rankListComparator;
	}

	public void addPlayer(Player player) {
		this.players.add(player);
	}

	public List<Group<T>> generateGroups(GroupGenerator<T> groupGenerator, int numberOfGroups) {
		return groupGenerator.createGroups(this.players, numberOfGroups);
	}

	public List<Encounter<T>> generateEncounters(Group<T> group) {
		List<Encounter<T>> generatedEncounters = new ArrayList<>();
		List<Player> groupPlayers = group.getPlayers();
		for (int i = 0; i < groupPlayers.size(); i++) {
			for (int j = 0; j < groupPlayers.size(); j++) {
				// players don't compete against themselves
				if (i != j) {
					generatedEncounters.add(new Encounter<>(groupPlayers.get(i), groupPlayers.get(j)));
				}
			}
		}
		return generatedEncounters;
	}

	public void compete(List<Encounter<T>> encounters, ResultGenerator<T> resultGenerator) {
		for (Encounter<T> encounter : encounters) {
			MatchUnitInfo<T> player1 = encounter.getPlayer1();
			MatchUnitInfo<T> player2 = encounter.getPlayer2();
			// randomly generate result
			resultGenerator.generateAndAssignResults(player1, player2, this.resultComparator);
			// assign result
			this.evaluateResults(player1, player2);
		}
	}

	public RankList<T> createRankList(Group<T> group) {
		Map<Player, RankListEntry> resultMap = new HashMap<>();

		for (Encounter<T> encounter : group.getEncounters()) {
			MatchUnitInfo<T> matchUnitInfoPlayer1 = encounter.getPlayer1();
			MatchUnitInfo<T> matchUnitInfoPlayer2 = encounter.getPlayer2();

			this.processEvaluatedMatchUnitInfo(matchUnitInfoPlayer1, resultMap);
			this.processEvaluatedMatchUnitInfo(matchUnitInfoPlayer2, resultMap);
		}
		return new RankList<>(resultMap.values(), this.rankListComparator);
	}

	private void processEvaluatedMatchUnitInfo(MatchUnitInfo<T> matchUnitInfo, Map<Player, RankListEntry> resultMap) {
		Player player = matchUnitInfo.getPlayer();
		// add to map
		resultMap.putIfAbsent(player, new RankListEntry(player));
		// eval
		resultMap.get(player).processResult(matchUnitInfo.getResult());
	}

	private void evaluateResults(MatchUnitInfo<T> player1, MatchUnitInfo<T> player2) {
		T scorePlayer1 = player1.getScore();
		T scorePlayer2 = player2.getScore();
		Result resultPlayer1 = null;
		Result resultPlayer2 = null;

		int comparison = scorePlayer1.compareTo(scorePlayer2);
		// player1 loses
		if (comparison < 0) {
			resultPlayer1 = Result.LOSS;
			resultPlayer2 = Result.VICTORY;
		} // draft
		else if (comparison == 0) {
			resultPlayer1 = Result.DRAW;
			resultPlayer2 = Result.DRAW;
		} // player1 wins
		else {
			resultPlayer1 = Result.VICTORY;
			resultPlayer2 = Result.LOSS;
		}
		player1.setResult(resultPlayer1);
		player2.setResult(resultPlayer2);
	}
}
