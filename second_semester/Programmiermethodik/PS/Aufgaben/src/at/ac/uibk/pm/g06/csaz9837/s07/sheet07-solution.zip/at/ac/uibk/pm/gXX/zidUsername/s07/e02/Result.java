package at.ac.uibk.pm.gXX.zidUsername.s07.e02;

public enum Result {
    VICTORY(3),
    DRAW(1),
    LOSS(0);

    private final int points;

    Result(int points) {
        this.points = points;
    }
    
    public int getPoints() {
		return points;
	}
    
}
