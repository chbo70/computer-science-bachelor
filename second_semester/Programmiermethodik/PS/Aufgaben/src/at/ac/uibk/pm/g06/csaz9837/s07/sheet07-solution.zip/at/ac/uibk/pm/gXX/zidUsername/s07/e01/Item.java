package at.ac.uibk.pm.gXX.zidUsername.s07.e01;

import java.util.Objects;

public class Item implements Identifiable<Long> {
	private String name;
	private double price;
	private Long id;

	public Item() {
	}

	public Item(Long id, String name, double price) {
		this.name = name;
		this.price = price;
		this.id = id;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		Item item = (Item) o;
		return Objects.equals(id, item.id);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, price);
	}

	@Override
	public Long getId() {
		return this.id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
