package at.ac.uibk.pm.gXX.zidUsername.s07.e02;

import java.util.List;

public interface GroupGenerator<T extends Comparable<T>> {

	List<Group<T>> createGroups(List<Player> competingEntities, int numberOfGroups);

}
