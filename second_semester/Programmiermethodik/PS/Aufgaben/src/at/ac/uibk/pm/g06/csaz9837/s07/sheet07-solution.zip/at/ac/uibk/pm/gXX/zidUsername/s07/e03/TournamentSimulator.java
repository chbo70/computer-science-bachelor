package at.ac.uibk.pm.gXX.zidUsername.s07.e03;

import java.util.Comparator;
import java.util.List;
import java.util.stream.IntStream;

import at.ac.uibk.pm.gXX.zidUsername.s07.e02.Encounter;
import at.ac.uibk.pm.gXX.zidUsername.s07.e02.Group;
import at.ac.uibk.pm.gXX.zidUsername.s07.e02.RandomGroupGenerator;
import at.ac.uibk.pm.gXX.zidUsername.s07.e02.RankListEntry;
import at.ac.uibk.pm.gXX.zidUsername.s07.e02.TennisPlayer;
import at.ac.uibk.pm.gXX.zidUsername.s07.e02.TournamentManager;

public class TournamentSimulator {

	private TournamentManager<Integer> tournamentManager;

	public TournamentSimulator() {
		Comparator<Integer> resultComparator = getTennisResultComparator();
		Comparator<RankListEntry> rankListComparator = getTennisRankingListComparator();
		this.tournamentManager = new TournamentManager<>(resultComparator, rankListComparator);
	}

	public void simulateTournament(int numberOfPlayers, int numberOfGroups) {
		// create + add players
		this.generateAndAddPlayersToTournament(numberOfPlayers);
		// create groups
		List<Group<Integer>> generatedGroups = this.tournamentManager.generateGroups(new RandomGroupGenerator<>(),
				numberOfGroups);
		// create encounters
		for (Group<Integer> group : generatedGroups) {
			group.setEncounters(this.tournamentManager.generateEncounters(group));
		}
		// compete
		RandomResultGenerator<Integer> randomResultGenerator = new RandomTennisResultGenerator();
		for (Group<Integer> group : generatedGroups) {
			this.tournamentManager.compete(group.getEncounters(), randomResultGenerator);
		}

		// ranklist per group
		Group<Integer> finalGroup = new Group<>("final group");
		// print all rank-lists
		for (Group<Integer> group : generatedGroups) {
			RankList<Integer> rankList = this.tournamentManager.createRankList(group);
			group.setRankList(rankList);
			group.printRankList();
			rankList.findLeadingPlayers().forEach(finalGroup::addPlayer);
		}

		// now compete final round
		List<Encounter<Integer>> encountersFinalGroup = this.tournamentManager.generateEncounters(finalGroup);
		finalGroup.setEncounters(encountersFinalGroup);
		this.tournamentManager.compete(encountersFinalGroup, randomResultGenerator);
		finalGroup.setRankList(this.tournamentManager.createRankList(finalGroup));
		finalGroup.printRankList();
	}

	private void generateAndAddPlayersToTournament(int numberOfPlayers) {
		IntStream.range(0, numberOfPlayers)
				.forEach(i -> this.tournamentManager.addPlayer(new TennisPlayer("player" + String.format("%02d", i))));
	}

	private Comparator<RankListEntry> getTennisRankingListComparator() {
		return (r1, r2) -> r2.getTotalAmountOfPoints().compareTo(r1.getTotalAmountOfPoints());
	}

	private Comparator<Integer> getTennisResultComparator() {
		return (i1, i2) -> i1.compareTo(i2);
	}

}
