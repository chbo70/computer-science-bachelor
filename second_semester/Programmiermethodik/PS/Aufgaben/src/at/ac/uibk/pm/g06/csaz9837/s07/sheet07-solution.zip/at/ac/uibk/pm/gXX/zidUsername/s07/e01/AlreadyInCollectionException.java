package at.ac.uibk.pm.gXX.zidUsername.s07.e01;

public class AlreadyInCollectionException extends Exception {
    private static final long serialVersionUID = 6985949618654224467L;

	AlreadyInCollectionException(String msg) {
        super(msg);
    }
}
