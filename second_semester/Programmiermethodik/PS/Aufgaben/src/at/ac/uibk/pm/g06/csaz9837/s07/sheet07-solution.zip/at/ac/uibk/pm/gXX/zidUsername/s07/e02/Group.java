package at.ac.uibk.pm.gXX.zidUsername.s07.e02;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import at.ac.uibk.pm.gXX.zidUsername.s07.e03.RankList;

public class Group<T extends Comparable<T>> {

	private final String name;
	private List<Player> players = new ArrayList<>();
	private List<Encounter<T>> encounters = new ArrayList<>();
	private RankList<T> rankList;

	public Group(String name) {
		this.name = name;
	}

	public Group(String name, List<Player> subList) {
		this(name);
		this.players = subList;
	}

	public String getName() {
		return name;
	}

	public List<Player> getPlayers() {
		return Collections.unmodifiableList(this.players);
	}

	public void addPlayer(Player player) {
		this.players.add(player);
	}

	public List<Encounter<T>> getEncounters() {
		return encounters;
	}

	public void setEncounters(List<Encounter<T>> encounters) {
		this.encounters = encounters;
	}

	public RankList<T> getRankList() {
		return rankList;
	}

	public void setRankList(RankList<T> rankList) {
		this.rankList = rankList;
	}

	public void printRankList() {
		this.rankList.print(this);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name);
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Group<T> other = (Group<T>) obj;
		return Objects.equals(name, other.name);
	}

	
	
}
