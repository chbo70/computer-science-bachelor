package at.ac.uibk.pm.g06.csaz9837.s08.e02;

public enum FoodType {
    FRUIT, VEGGIE, MEAT, DAIRY, SWEETS, MUNCHIES
}
