package at.ac.uibk.pm.g06.csaz9837.s08.e03;

public class SimpleLazyEvaluationExample {

    public static void main(String[] args) {
        boolean aTrue = true;
        boolean aFalse = false;

        if (aTrue|| aFalse) {
            System.out.println("match");
        }
    }
}
