package at.ac.uibk.pm.g06.csaz9837.midterm2.e01;

import java.util.Comparator;

public class SortedTripleApplication {
    public static void main(String[] args) {
        SortedTriple<String> tripleString = new SortedTriple<>("Buli", "Biba", "Zamantha");
        System.out.println(tripleString);
        tripleString.reverseOrder();
        System.out.println(tripleString);
        Comparator<String> comp = (o1, o2) -> {
            if (o1.length() > o2.length()) {
                return 1;
            } else if (o1.length() < o2.length()) {
                return -1;
            } else {
                return 0;
            }
        };
        System.out.println(tripleString.sortWithNewComp(comp));
    }
}
