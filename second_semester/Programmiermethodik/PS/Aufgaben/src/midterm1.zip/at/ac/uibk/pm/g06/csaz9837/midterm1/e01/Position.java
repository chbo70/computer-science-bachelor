package at.ac.uibk.pm.g06.csaz9837.midterm1.e01;

public enum Position {
    LEFT,
    CENTER,
    RIGHT
}
