package at.ac.uibk.pm.g06.csaz9837.midterm1.e03;

public enum Condition {
    NEW,
    GOOD_AS_NEW,
    OBVIOUS_SIGNS_OF_WEAR
}
