package at.ac.uibk.pm.g06.csaz9837.s07.e02;

import java.util.*;

public class RandomGroupGenerator<T> implements GroupGenerator<T>{
    @Override
    public Group<T> groupGenerator(List<Player<T>> players, int numberOfGroups) {
        Collections.shuffle(players);
        List<Player<T>> newPlayerList = new ArrayList<>();
        for (int i = 0; i < players.size()/numberOfGroups; i++) {
            newPlayerList.add(players.get(i));
        }
        for (int i = 0; i < players.size(); i++) {
            System.out.println(players.get(i));
        }
        return new Group<>(newPlayerList);
    }
}
