package at.ac.uibk.pm.g06.csaz9837.s07.e02;

public class ResultGenerator {
}
