package at.ac.uibk.pm.g06.csaz9837.s06.e03;

public class FixedVoteGenerator {
}
