#=
    Scalar/Scalar Multiplication
    hint: you can use `exp(log(a)+log(b))` to multiply two positive float values
=#
function multiply(a::Float64, b::Float64)
    res = exp10(log10(abs(a)) + log10(abs(b)))
    xor(a < 0, b < 0) ? -res : res
    # a/(1.0/b)
end

#= Scalar/Vector Multiplication =#
function multiply(a::Float64, b::Array{Float64,1})
    multiply.(a, b)
end

#= Scalar/Matrix Multiplication =#
function multiply(a::Float64, b::Array{Float64,2})
   multiply.(a, b) 
end

#= Dot Product =#
function dot(r, c)
    sum(multiply.(r, c))
end

#= Vector/Matrix Multiplication =#
function multiply(a::Array{Float64,1}, b::Array{Float64,2})
    (x -> dot(a, x)).(eachrow(b))
    # map( x -> dot(a, x), eachrow(b) )
end

#= Matrix/Matrix Multiplication =#
function multiply(a::Array{Float64,2}, b::Array{Float64,2})
    mapslices( x -> multiply(x, b), a, dims=2 )
end

#= Matrix/Matrix Addition =#
function add(a::Array{Int,2}, b::Array{Int,2})
    a + b
end

#= Matrix Transpose =#
function transpose(a::Array{Int,2})
    permutedims(a)
end

#===============================================================================
        Test Cases (do not touch these!)
===============================================================================#
#= Scalar/Scalar Multiplication =#
@assert multiply( 1.0,  2.0) == ( 1.0 *  2.0)
@assert multiply( 1.0,  1.0) == ( 1.0 *  1.0)
@assert multiply( 0.0,  1.0) == ( 0.0 *  1.0)
@assert multiply(-1.0,  2.0) == (-1.0 *  2.0)
@assert multiply(-1.0,  1.0) == (-1.0 *  1.0)
@assert multiply(-0.0,  1.0) == (-0.0 *  1.0)
@assert multiply(-1.0, -2.0) == (-1.0 * -2.0)
@assert multiply(-1.0, -1.0) == (-1.0 * -1.0)
@assert multiply(-0.0, -1.0) == (-0.0 * -1.0)
@assert multiply( 1.0, -2.0) == ( 1.0 * -2.0)
@assert multiply( 1.0, -1.0) == ( 1.0 * -1.0)
@assert multiply( 0.0, -1.0) == ( 0.0 * -1.0)

#= Scalar/Vector Multiplication =#
@assert multiply(2.0, [1.0, 2.0]) == (2.0 * [1.0, 2.0])
@assert multiply(0.0, [1.0, 2.0]) == (0.0 * [1.0, 2.0])
@assert multiply(0.0, [1.0, 2.0]) != [0.0, 2.0]
@assert multiply(3.0, [3.0, 1.0]) == (3.0 * [3.0, 1.0])
@assert multiply(3.0, [3.0, 1.0]) == (3.0 * [3.0, 1.0])

#= Scalar/Matrix Multiplication =#
@assert multiply(0.0, [1.0  2.0]) == (0.0 * [1.0  2.0])
@assert multiply(2.0, [1.0  2.0]) == (2.0 * [1.0  2.0]) 

@assert multiply(1.0, [[1.0,2.0] [1.0,2.0]]) == (1.0 * [[1.0,2.0] [1.0,2.0]])
@assert multiply(1.0, [[1.0 2.0] [1.0 2.0]]) == (1.0 * [[1.0 2.0] [1.0 2.0]])
@assert multiply(2.0, [[1.0,2.0] [1.0,2.0]]) == (2.0 * [[1.0,2.0] [1.0,2.0]])
@assert multiply(2.0, [[1.0 2.0] [1.0 2.0]]) == (2.0 * [[1.0 2.0] [1.0 2.0]])
@assert multiply(0.0, [[1.0,2.0] [1.0,2.0]]) != [[0.0, 0.0] [1.0, 2.0]]
@assert multiply(0.0, [[1.0 2.0] [1.0 2.0]]) != [[0.0 0.0] [1.0 2.0]]

#= Dot Product =#
@assert dot([1.0,1.0], [1.0,1.0]) == 2.0
@assert dot([0.0,1.0], [1.0,1.0]) == 1.0
@assert dot([0.0,0.0], [1.0,1.0]) == 0.0
@assert dot([0.0,0.0], [0.0,0.0]) == 0.0
@assert dot([1.0 1.0], [1.0 1.0]) == 2.0
@assert dot([0.0 1.0], [1.0 1.0]) == 1.0
@assert dot([0.0 0.0], [1.0 1.0]) == 0.0
@assert dot([0.0 0.0], [0.0 0.0]) == 0.0
@assert dot([0.0,2.0], [1.0,2.0]) == 4.0
@assert dot([0.0,2.0], [1.0,1.0]) == 2.0

#= Vector/Matrix Multiplication =#
@assert multiply([0.0,0.0], [[1.0,1.0] [1.0,1.0]]) == [0.0,0.0]
@assert multiply([0.0,2.0], [[1.0,1.0] [1.0,1.0]]) == [2.0,2.0]
@assert multiply([1.0,2.0], [[1.0,1.0] [1.0,1.0]]) == [3.0,3.0]
@assert multiply([2.0,2.0], [[1.0,1.0] [1.0,1.0]]) == [4.0,4.0]
@assert multiply([0.0,0.0], [[1.0,2.0] [1.0,1.0]]) == [0.0,0.0]
@assert multiply([0.0,2.0], [[1.0,2.0] [1.0,1.0]]) == [2.0,2.0]
@assert multiply([1.0,2.0], [[1.0,2.0] [1.0,1.0]]) == [3.0,4.0]
@assert multiply([2.0,2.0], [[1.0,2.0] [1.0,1.0]]) == [4.0,6.0]

#= Matrix/Matrix Multiplication =#
@assert multiply([[0.0,0.0] [0.0,0.0]], [[1.0,1.0] [1.0,1.0]]) == [[0.0,0.0] [0.0,0.0]]
@assert multiply([[0.0,0.0] [1.0,1.0]], [[1.0,1.0] [1.0,1.0]]) == [[1.0,1.0] [1.0,1.0]]
@assert multiply([[1.0,1.0] [1.0,1.0]], [[1.0,1.0] [1.0,1.0]]) == [[2.0,2.0] [2.0,2.0]]
@assert multiply([[0.0,0.0] [0.0,1.0]], [[1.0,1.0] [1.0,1.0]]) == [[0.0,1.0] [0.0,1.0]]
@assert multiply([[0.0,1.0] [0.0,1.0]], [[1.0,1.0] [1.0,1.0]]) == [[0.0,2.0] [0.0,2.0]]
@assert multiply([[1.0,0.0] [1.0,0.0]], [[1.0,1.0] [1.0,1.0]]) == [[2.0,0.0] [2.0,0.0]]

#= Matrix Transpose =#
@assert transpose([[0] [0]]) == [0 0]'
@assert transpose([[1] [2]]) == [1 2]'
@assert transpose([[1,1] [2,2]]) == [1 2; 1 2]'
@assert transpose([[1,2] [3,4]]) == [1 3; 2 4]'
@assert transpose([[1,1,1,1] [2,2,2,2]]) == [1 2; 1 2; 1 2; 1 2]'
@assert transpose([[1] [2] [3] [4]]) == [1 2 3 4]'

#= Matrix/Matrix Addition =#
@assert add([[9,8,7] [6,5,4] [3,2,1]],
            [[1,2,3] [4,5,6] [7,8,9]]) == [[9,8,7] [6,5,4] [3,2,1]] + [[1,2,3] [4,5,6] [7,8,9]]
@assert add([[-1,-2,-3] [-4,-5,-6] [-7,-8,-9]],
            [[1,2,3] [4,5,6] [7,8,9]]) == [[-1,-2,-3] [-4,-5,-6] [-7,-8,-9]] + [[1,2,3] [4,5,6] [7,8,9]]
