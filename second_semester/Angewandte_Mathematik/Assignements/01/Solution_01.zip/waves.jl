using Plots

y(t, A, f) = A * sin.(2π * f * t) 

E(t) = y(t, 1, 329.0)
G_sharp(t) = y(t, 1, 425.30)
B(t) = y(t, 1, 493.88)

triad(t) = E(t) + G_sharp(t) + B(t)

p = plot( 0:0.0001:0.016, [E, G_sharp, B], label=["E 329.63Hz", "G# 425.30Hz", "B 493.88Hz"], title="Triad Sound Waves" )
plot!(p,  0:0.0001:0.016, triad, label="triad", width=3)

display(p)