using Plots

p = plot( 0:0.1:2π, sin, label="sine", title="Trigonometry Functions" )
plot!( 0:0.1:2π,  cos, label="cosine")

display(p)