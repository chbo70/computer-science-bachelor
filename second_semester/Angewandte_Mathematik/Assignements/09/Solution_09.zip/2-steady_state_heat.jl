using LinearAlgebra
using Plots

include("2-iterative_solvers.jl")


#---------------------- Discretization Matrix ----------------------
N = 20

D = Matrix{Float64}(4.0*I, N-2, N-2)
D[diagind(D, 1)] .= -1
D[diagind(D, -1)] .= -1

A = kron(Matrix{Float64}(I, N-2, N-2), D)
A[diagind(A, N-2)] .= -1
A[diagind(A, -(N-2))] .= -1

u = zeros( N, N )

#------------------------- Boundaries -----------------------------
walltemp = 18.0
heatertemp = 30.0
windowtemp = 10.0

u[:, 1] .= walltemp
u[:, end] .= walltemp
u[1, :] .= walltemp
u[end, :] .= walltemp

_N = (N/10.0)
bWindow = range( Int( floor(_N*3) ), stop = Int( floor(_N*8) ) )
bHeater_1 = range( Int( floor(_N*2 ) ), stop = Int( floor(_N*4) ) )
bHeater_2 = range( Int( floor(_N*7) ), stop = Int( floor(_N*9) ) )
u[bWindow, end] .= windowtemp
u[bHeater_1, 1] .= heatertemp
u[bHeater_2, 1] .= heatertemp

#---------------- solution vector and rhs vector ------------------
x = vec( @view u[2:end-1, 2:end-1] )

# rhs vector (added boundary conditions)
b = zeros( N - 2, N - 2 )
b[:, 1] += u[2:end-1, 1]
b[:, end] += u[2:end-1, end]
b[1, :] += u[1, 2:end-1]
b[end, :] += u[end, 2:end-1]

b = vec(b);


#------------------------------ Solve Laplace Equation ------------------------------
#------------------------------ [ Exercise 2 ] ------------------------------
# TODO: Solve the Laplace Equation with gaußSeidel and conjugate gradients

#@time x[:, :], r = jacobi(A, b, 1000)
#@time x[:, :], r = gaußSeidel(A, b, 1000)
@time x[:, :], r = conjgrad(A, b, 1000)

plot(
    heatmap(u, c=:thermal, aspect_ratio=:equal, axis=nothing, title="Temperature"),

    surface(1:N, 1:N, u, zlabel="Temperature", camera=(45, 45), fillalpha=0.9, colorbar=false),

    plot(r, label=false, title="Convergence of CG",
            xlabel="iterations", ylabel="residual norm", width=3,
            yaxis=:log10, xlim=(0, length(r)), ylims=(r[end], r[1])
            ),
    layout = (1, 3), size=(480*3, 480)
    )
#------------------------------ [ Exercise 2 ] ------------------------------
