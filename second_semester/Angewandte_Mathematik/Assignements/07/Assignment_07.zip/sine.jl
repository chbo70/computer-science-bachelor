# package for ploting functions
using Plots
# use GR
gr()



X = range(-5*π, stop=5*π, length=256)


# sin(x) approximation using Taylor series
function sinApprox(x, n)
	return 0;						### <-- EXERCISE 5(b): implement the formula for the Taylor series of sin(x) given a value of n.
end


function error(x, n)
	return 0;						### <-- EXERCISE 5(c): calculate absolute error between the n-th Taylor series and the real value of sin(x). 
end


# plot real sin(x)
plt1 = plot(X, sin, xlim = (-4*π, 4*π),  ylim = (-2, 2), color=:blue, lw = 3, label="sin(x)" );


n = 5;
# plot taylor series for n=5
plot!(plt1, X, sinApprox.(X, n), xlim = (-5*π, 5*π),  ylim = (-2, 2), color=:orange, lw = 3, label="n=5");
# plot error for n=5
plt2 = plot(X,  error.(X, n) , xlim = (-4*π, 4*π),  ylim = (-1, 2), color=:orange, label="error n=5" );




#...

	### <-- EXERCISE 5(b): plot taylor series for n=10 and n=15 in plt1.
	
	### <-- EXERCISE 5(c): plot error for n=10 and n=15 in plt2.

#...




# show plots
display( plot( plt1, plt2, layout = (2, 1) ))

